<?php

echo "permission denied";

?>