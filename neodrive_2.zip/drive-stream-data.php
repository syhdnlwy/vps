<?php
goto ZMIn5yoGr4J1XtFp;
SHtcgV2_09PDHxgi:
$djNfnfY2kWdPbHcn = json_decode(file_get_contents("base/data/main/share/{$aiBYHZ3I2UpgLN0q}.json"), true);
goto nzAzWzwoD6I1TZPg;
sG0BDiXj28653Yai:
function SvkEX0CgBEAvLk1E($aiBYHZ3I2UpgLN0q, $AYdDFRROs0RAdupf)
{
goto o01sSUac786A79G7;
K2H395s3wHT0Ja6l:
parse_str($ZqIKy5pq5yqpCViD, $ldoWRg21HAGwI4KV);
goto uupjgd18rTG8lz5z;
uupjgd18rTG8lz5z:
$djNfnfY2kWdPbHcn = explode(",", $ldoWRg21HAGwI4KV["fmt_stream_map"]);
goto BSZFCTl7uVNPyE8V;
KX1r5A69F3yubgJT:
$ZqIKy5pq5yqpCViD = U2EdP9DvzZa6jxyv($NOhiPL7MtIQhTMOP, $AYdDFRROs0RAdupf);
goto K2H395s3wHT0Ja6l;
BSZFCTl7uVNPyE8V:
foreach ($djNfnfY2kWdPbHcn as $aj44tBwVogPFvlpI) {
goto OqXJ4Y38PXyJwZJa;
OqXJ4Y38PXyJwZJa:
switch ((int) substr($aj44tBwVogPFvlpI, 0, 2)) {
case 18:
$BwrMoYMcpNzyx1gq = "360P";
goto g12RHskJYUggOnDd;
case 22:
$BwrMoYMcpNzyx1gq = "720P";
goto g12RHskJYUggOnDd;
case 37:
$BwrMoYMcpNzyx1gq = "1080P";
goto g12RHskJYUggOnDd;
case 59:
$BwrMoYMcpNzyx1gq = "480P";
goto g12RHskJYUggOnDd;
default:
goto g12RHskJYUggOnDd;
}
goto IgWMs1SyE04T4Yn4;
IgWMs1SyE04T4Yn4:
YC0Vv_d4bCL8FbMn:
goto q7uEVGxxkaX1jVVd;
q7uEVGxxkaX1jVVd:
g12RHskJYUggOnDd:
goto xE7MlXYdpwaCBG5R;
o1o8fyagZcbX8Leb:
pwlFJqbpAly2gCJ4:
goto fioDMqUmw2j4SoM6;
xE7MlXYdpwaCBG5R:
$e7qLKtD6pGNoTZCO[$BwrMoYMcpNzyx1gq] = substr(preg_replace("/wkwkwkw/", "astagfirullah", $aj44tBwVogPFvlpI), 3);
goto o1o8fyagZcbX8Leb;
fioDMqUmw2j4SoM6:
}
goto XEitGrZGQm8LZvvf;
HyKy4X7akhzFkTO0:
return $e7qLKtD6pGNoTZCO;
goto wAAWWiaFLtq2Q_fG;
jN0c_a0yGNTE6x1A:
$NOhiPL7MtIQhTMOP = "https://docs.google.com/get_video_info?docid={$aiBYHZ3I2UpgLN0q}";
goto KX1r5A69F3yubgJT;
XEitGrZGQm8LZvvf:
CY5c0k0BuyVqbly9:
goto zjlOn7Ziynem4h1U;
zjlOn7Ziynem4h1U:
ksort($e7qLKtD6pGNoTZCO);
goto HyKy4X7akhzFkTO0;
o01sSUac786A79G7:
$e7qLKtD6pGNoTZCO = [];
goto jN0c_a0yGNTE6x1A;
wAAWWiaFLtq2Q_fG:
}
goto GocRGT89xYBV0X8l;
qPgqmm01OET6Bc5R:
$ZCj8Ev1pZOrHm6au = "base/data/main/player/data";
goto sNDutvfNX8Mo2_Ht;
PbdWt0mmHh1DK0Xg:
function MqL9nI6lSTrLgD1s($IxiqQzBk_ESjWqNy, $aiBYHZ3I2UpgLN0q)
{
goto V_UFr1NjsHtzG0of;
VU5ihfa6AzpEOL3N:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_FOLLOWLOCATION, true);
goto TNv6Q6vCwSHbHNfz;
lHuEfOXaLNOkHUhG:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.125 Safari/533.4");
goto KIDjsSwQVgkk4c2C;
U7Dtv9AzF39TruYW:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_SSL_VERIFYPEER, TRUE);
goto zNyMYZIJfFAPxT7r;
KIDjsSwQVgkk4c2C:
print_r(curl_exec($pdNf94OTVoN4o2eJ));
goto sjgijAeGbWMisJvd;
csk823ticL_ywCdv:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_RETURNTRANSFER, TRUE);
goto lHuEfOXaLNOkHUhG;
TNv6Q6vCwSHbHNfz:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_URL, $IxiqQzBk_ESjWqNy);
goto csk823ticL_ywCdv;
zNyMYZIJfFAPxT7r:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_COOKIEFILE, dirname(__FILE__) . "/base/data/main/player/cookie/" . $aiBYHZ3I2UpgLN0q . ".txt");
goto VU5ihfa6AzpEOL3N;
V_UFr1NjsHtzG0of:
$pdNf94OTVoN4o2eJ = curl_init();
goto U7Dtv9AzF39TruYW;
sjgijAeGbWMisJvd:
}
goto sG0BDiXj28653Yai;
EF0gEQFQ_k7dMk0R:
$mgLDiDMegJCstYO0 = "base/data/main/player/cookie";
goto qPgqmm01OET6Bc5R;
GocRGT89xYBV0X8l:
function QyhCLbtGkMIA_49X($KsEmYU7W_VVLl7IJ)
{
goto oZjyUjEkx6BFdAOO;
T7PYFJELGmIbMR4S:
goto wxnRJHn6j7oGpG3j;
goto v7uTQvn8cvJRhM0S;
x3r5H2R1zrmh3F9c:
if ($S1aNfM106AjX1DNd > $KsEmYU7W_VVLl7IJ) {
goto nDIFKzWQGfzO674N;
}
goto r0LhsL8feFC0zyfl;
v7uTQvn8cvJRhM0S:
nDIFKzWQGfzO674N:
goto pD2pm8EAK9seOyMp;
xUiaw032wsHtyfSJ:
return $hq5G1MAUZxxkI1QL;
goto X_aQWtO0aBdJSb5t;
eSj_d9r2cPIlRkIh:
if (!($KsEmYU7W_VVLl7IJ == null)) {
goto l51HsJvmtG6PGxNz;
}
goto yCfEqUeSubOtNf2Z;
pD2pm8EAK9seOyMp:
$hq5G1MAUZxxkI1QL = true;
goto VMKS1PXhBmWCVNkX;
r0LhsL8feFC0zyfl:
$hq5G1MAUZxxkI1QL = false;
goto T7PYFJELGmIbMR4S;
DJFPntuKHUyLgxla:
l51HsJvmtG6PGxNz:
goto x3r5H2R1zrmh3F9c;
VMKS1PXhBmWCVNkX:
wxnRJHn6j7oGpG3j:
goto xUiaw032wsHtyfSJ;
oZjyUjEkx6BFdAOO:
$S1aNfM106AjX1DNd = strtotime("now");
goto eSj_d9r2cPIlRkIh;
yCfEqUeSubOtNf2Z:
$KsEmYU7W_VVLl7IJ = 1;
goto DJFPntuKHUyLgxla;
X_aQWtO0aBdJSb5t:
}
goto xzETEi5IRQkW2JQz;
aUPmhtWMkOc5kJEp:
eUSMq9WgRXkCzNkB:
goto cf8T_fLW8XOa9CoE;
ZThN59xTS_P8PqgE:
G7NMlfczGkQf4bZO:
goto xBTcdelNxjmQEw60;
k17T32RO8VnCU4we:
foreach ($JAjaJD695VkqKlWL as $GOdt3r6djUaboStw => $BwrMoYMcpNzyx1gq) {
$nB3JUu3eFLMVLVds[] = array("file" => $BwrMoYMcpNzyx1gq, "type" => "video/mp4", "label" => $GOdt3r6djUaboStw);
vIu6ioFdHd5XiDYU:
}
goto aUPmhtWMkOc5kJEp;
xBTcdelNxjmQEw60:
$aiBYHZ3I2UpgLN0q = $_GET['id'];
goto SHtcgV2_09PDHxgi;
dKb0yJYMXUrcpeAI:
if (is_dir($ZCj8Ev1pZOrHm6au)) {
goto G7NMlfczGkQf4bZO;
}
goto roczCB5MxloKoMTG;
cf8T_fLW8XOa9CoE:
$t0KJJPBsCJjkjReV = strtotime('+3 hours');
goto abeH2DLJd1VQCG4b;
IFA_qReszlF033kA:
yyG8qPsgZeTtrlY6:
goto dKb0yJYMXUrcpeAI;
nzAzWzwoD6I1TZPg:
$LQ_iEZUm6MBBnPt2 = $djNfnfY2kWdPbHcn['file']['file_id'];
goto UEPt2m68Sz5P0jSL;
UEPt2m68Sz5P0jSL:
$JAjaJD695VkqKlWL = sVKEx0CgbeavlK1E($LQ_iEZUm6MBBnPt2, $aiBYHZ3I2UpgLN0q);
goto VVU_hXnMQiVCvkhM;
utUZVGiHEpyko2os:
$rp_n4IZ2d9VTeNuk = "base/data/main/player";
goto EF0gEQFQ_k7dMk0R;
z3KsY0Jgls_YSfSF:
if (!isset($_GET['id'])) {
goto r2bQkR2wLMzf48q0;
}
goto utUZVGiHEpyko2os;
abeH2DLJd1VQCG4b:
$qzQdAp0qgTRWYGcd = array('id' => $aiBYHZ3I2UpgLN0q, 'video' => $nB3JUu3eFLMVLVds, 'valid' => $t0KJJPBsCJjkjReV);
goto ITRWNFWMxoUn7rq8;
CgJa6ml_OeESc2Y7:
function iZ0pr0T4m0USG32H($djNfnfY2kWdPbHcn)
{
goto wYup2FUY0KKSpqC7;
Sw_aigabUd7ucGld:
$Rakyi3mJ3ooKFAD5 = trim($Rakyi3mJ3ooKFAD5);
goto SfRVuVpXNJsQxPm2;
Y2Bxh3kTqzM6oH55:
$ko7lSpTCQESFMWYJ = $ko7lSpTCQESFMWYJ['1'];
goto z2gDX9PhcPRUTWJd;
dezAHojwqz29unvA:
$Llm2DSU63mZq0dXS = str_replace(array(" ", "\n\r", "\n", "\r"), "", $Llm2DSU63mZq0dXS);
goto k4ZLHQK8hP9GhCi3;
jd2npcX6icJXsKx0:
$Llm2DSU63mZq0dXS = explode("NID", $djNfnfY2kWdPbHcn);
goto ZzzrPApQmjIAHluN;
k4ZLHQK8hP9GhCi3:
$BLscRJMKAr5HEQ0L = strpos($Llm2DSU63mZq0dXS, "#");
goto SJEGLF3hPvXQIgp6;
A9lKWqILd0CA7VTr:
$Gf38z9S5LdLoWBjf = array("NID=" . $Rakyi3mJ3ooKFAD5 . "", "DRIVE_STREAM=" . $ko7lSpTCQESFMWYJ . "");
goto cuCHzwL_Y8cF4mBl;
SfRVuVpXNJsQxPm2:
$ko7lSpTCQESFMWYJ = trim($ko7lSpTCQESFMWYJ);
goto A9lKWqILd0CA7VTr;
SJEGLF3hPvXQIgp6:
$Rakyi3mJ3ooKFAD5 = substr($Llm2DSU63mZq0dXS, 0, $BLscRJMKAr5HEQ0L);
goto Sw_aigabUd7ucGld;
cuCHzwL_Y8cF4mBl:
return $Gf38z9S5LdLoWBjf;
goto sN2cARjsdmzDerZV;
wYup2FUY0KKSpqC7:
$ko7lSpTCQESFMWYJ = explode("DRIVE_STREAM", $djNfnfY2kWdPbHcn);
goto Y2Bxh3kTqzM6oH55;
ZzzrPApQmjIAHluN:
$Llm2DSU63mZq0dXS = $Llm2DSU63mZq0dXS['1'];
goto dezAHojwqz29unvA;
z2gDX9PhcPRUTWJd:
$ko7lSpTCQESFMWYJ = str_replace(array(" ", "\n\r", "\n", "\r"), "", $ko7lSpTCQESFMWYJ);
goto jd2npcX6icJXsKx0;
sN2cARjsdmzDerZV:
}
goto z3KsY0Jgls_YSfSF;
VVU_hXnMQiVCvkhM:
$nB3JUu3eFLMVLVds = array();
goto k17T32RO8VnCU4we;
ZMIn5yoGr4J1XtFp:
error_reporting(0);
goto Kl0UcXL65301qFIr;
ITRWNFWMxoUn7rq8:
file_put_contents("base/data/main/player/data/{$aiBYHZ3I2UpgLN0q}.json", json_encode($qzQdAp0qgTRWYGcd, true));
goto BYZV4A5Sfo_Jy1ai;
SW0LPEjEn0c2OK4h:
mkdir($rp_n4IZ2d9VTeNuk, 0777, true);
goto NfUIoYn2wThMKVYn;
xzETEi5IRQkW2JQz:
function XWvTUOS4TttQbT78($EUY3AeM1pGvDm2ny = null, $bSuVLSP4gf135JYw = null, $YAWZ6pU5NObtalh3 = null)
{
goto HBNCh5ItfUTdIkd7;
hCY3qMMePenn01yk:
return $epe33EV2eSNSaBf8;
goto wg0q83pHBqsDglDz;
gsT8ja4xsDv7dbK3:
zHt04KuGfgKNBwK2:
goto hCY3qMMePenn01yk;
Tp_6GfqIA6sBaxCB:
$epe33EV2eSNSaBf8['http']['proxy'] = $bSuVLSP4gf135JYw;
goto FVojlsSY5hVTXGkJ;
HBNCh5ItfUTdIkd7:
$epe33EV2eSNSaBf8 = array('http' => array('method' => 'GET', 'user-agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36', 'header' => "Accept-language: en\r\n" . (!empty($YAWZ6pU5NObtalh3) ? "Proxy-Authorization: Basic {$YAWZ6pU5NObtalh3}\r\n" : '') . (!empty($EUY3AeM1pGvDm2ny) ? "Cookie: " . implode('; ', (array) $EUY3AeM1pGvDm2ny) . "\r\n" : '')));
goto rNUTyqpYwqFA8PRU;
rNUTyqpYwqFA8PRU:
if (empty($bSuVLSP4gf135JYw)) {
goto zHt04KuGfgKNBwK2;
}
goto Tp_6GfqIA6sBaxCB;
FVojlsSY5hVTXGkJ:
$epe33EV2eSNSaBf8['http']['request_fulluri'] = true;
goto gsT8ja4xsDv7dbK3;
wg0q83pHBqsDglDz:
}
goto CgJa6ml_OeESc2Y7;
NfUIoYn2wThMKVYn:
WjDNfmJ2l0vN0Ujq:
goto iIybhcPzOzyCoIyi;
roczCB5MxloKoMTG:
mkdir($ZCj8Ev1pZOrHm6au, 0777, true);
goto ZThN59xTS_P8PqgE;
sNDutvfNX8Mo2_Ht:
if (is_dir($rp_n4IZ2d9VTeNuk)) {
goto WjDNfmJ2l0vN0Ujq;
}
goto SW0LPEjEn0c2OK4h;
iIybhcPzOzyCoIyi:
if (is_dir($mgLDiDMegJCstYO0)) {
goto yyG8qPsgZeTtrlY6;
}
goto GZgy77wQft8OzxA8;
Kl0UcXL65301qFIr:
function u2edP9dvZZa6Jxyv($IxiqQzBk_ESjWqNy, $aiBYHZ3I2UpgLN0q)
{
goto dyZet51dzbFN30kA;
ZlrNJkGHqIhuapr0:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_FOLLOWLOCATION, true);
goto iTym1R2jn6FNF1ZA;
Q8PLvaXvY9QDD4yu:
return $P115pLRIa5CHDvdy;
goto nO6MjkPLHkiyyXrK;
MFc3051wpghWLE6B:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_COOKIEJAR, dirname(__FILE__) . "/base/data/main/player/cookie/" . $aiBYHZ3I2UpgLN0q . ".txt");
goto k2rWUePGZhLhkFCt;
nqEiFByzDynGTcLJ:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_SSL_VERIFYPEER, TRUE);
goto ZlrNJkGHqIhuapr0;
d6SE0oOw4tPJKC6W:
curl_close($pdNf94OTVoN4o2eJ);
goto Q8PLvaXvY9QDD4yu;
jFK6mXEg418B31W0:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_RETURNTRANSFER, TRUE);
goto MFc3051wpghWLE6B;
PVjiJWuBEqrge0GM:
$P115pLRIa5CHDvdy = curl_exec($pdNf94OTVoN4o2eJ);
goto d6SE0oOw4tPJKC6W;
iTym1R2jn6FNF1ZA:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_URL, $IxiqQzBk_ESjWqNy);
goto jFK6mXEg418B31W0;
k2rWUePGZhLhkFCt:
curl_setopt($pdNf94OTVoN4o2eJ, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.125 Safari/533.4");
goto PVjiJWuBEqrge0GM;
dyZet51dzbFN30kA:
$pdNf94OTVoN4o2eJ = curl_init();
goto nqEiFByzDynGTcLJ;
nO6MjkPLHkiyyXrK:
}
goto PbdWt0mmHh1DK0Xg;
GZgy77wQft8OzxA8:
mkdir($mgLDiDMegJCstYO0, 0777, true);
goto IFA_qReszlF033kA;
BYZV4A5Sfo_Jy1ai:
r2bQkR2wLMzf48q0:

?>