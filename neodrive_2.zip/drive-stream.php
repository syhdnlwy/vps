<?php
goto KlTk9FJFFlTS8jEp;
C9OMN960a8HmTbAS:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_FRESH_CONNECT, true);
goto eC_Qb4jeq2D5p9Eg;
s9lSdgpNF38UJDIs:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_FOLLOWLOCATION, true);
goto M8CbGYAz19Of_Z2s;
YYYjyVdKpIGq0x1H:
preg_match('/bytes=(\\d+)-(\\d+)?/', $_SERVER['HTTP_RANGE'], $tNLwAxH4tohQNp34);
goto dVwF33ocHra_LPBQ;
hE_oxieqFaSfgMzQ:
$rx8e6OgOxd7QgeeI = $QoiP904uIE6OMneX - $oa7ZLSHurUbiT1vG - 1;
goto vuTSQDodvy7ZginP;
TmBrJkX0XLjikaJe:
vP_GldYBKT5Y_Bhg:
goto pLTyL_RdS1FypK0B;
Z3bLsUeQsHJRZpSd:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_NOBODY, false);
goto nFJ49FuQN0yVGuOn;
dkapJK_o97Vg6a5W:
eOHoyW9ioxpFbY25:
goto wgb2OCm4YvUXlsCe;
nY0X7ERfeWB_xjsQ:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_VERBOSE, 1);
goto GYq_iCYFYqqpJbIb;
iCJ6Q_1C4kfmGCjL:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_TIMEOUT, 222222);
goto JE0VunL0zKUu9cMy;
csBT6dMlf1S52UfU:
ob_flush();
goto gc8XRRJLvi6_uK2N;
nFJ49FuQN0yVGuOn:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_RETURNTRANSFER, false);
goto R7wBsx8ALzPXZnal;
PRp9_r3PRaNkKBSP:
goto vP_GldYBKT5Y_Bhg;
goto dkapJK_o97Vg6a5W;
rNBEotEhaboHWeoR:
$oa7ZLSHurUbiT1vG = 0;
goto BF3erxwrhZUQAnF7;
Bc_FzqFIt2WOLfky:
FGJDlmYHtMQ53Fi_:
goto nD_aGAfF3ZWcZ_0V;
Ekog1aGi1L6MN0Pk:
header("Content-Type: video/mp4");
goto P5Lgngjdqf_iihFz;
pSBQhBOnQCS2ZX9p:
goto H78VdJnxe60pOKJW;
goto Bc_FzqFIt2WOLfky;
OL_aSv6yFRTWTxOi:
$pNBNfglmkeNuETzf = true;
goto YYYjyVdKpIGq0x1H;
t39Q8bdFIsEVEcIY:
if (!isset($_SERVER['HTTP_RANGE'])) {
goto g1Au_sYLG6XoIzpb;
}
goto OL_aSv6yFRTWTxOi;
xeErxEAFJZdU0USs:
header('Accept-Ranges: bytes');
goto PRp9_r3PRaNkKBSP;
oi5N5WeBumFPiChQ:
if (!($HwMMDtxUvKjVpP_n < $UXFY7oWvvpkS6UqT && $UXFY7oWvvpkS6UqT < $vQxTuQeljcFuzR8w)) {
goto undTmvk63I5n113l;
}
goto rLSyfX75kmOR21X5;
yCHuxoPOetDFsqVK:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_COOKIEFILE, dirname(__FILE__) . "/base/data/main/player/cookie/" . $v6wkZj0p1lz2eAe0 . ".txt");
goto gHI27tQDfRiWGAzz;
JuiB46d1SbMxKVBP:
$UXFY7oWvvpkS6UqT = $_GET['idplay'] - 989806;
goto oi5N5WeBumFPiChQ;
pLTyL_RdS1FypK0B:
header("Content-length: " . $rx8e6OgOxd7QgeeI);
goto afiayscHY207PzxD;
CG22BHAMp7mMVTlA:
header('Accept-Ranges: bytes');
goto XnCwDlk3nCxSRR8Q;
BbJHBu8fyGBuSLoB:
$N7yaF5WxzrDvINzW = $_GET['label'];
goto JuiB46d1SbMxKVBP;
L0tPi0lrr7J3WySY:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_SSL_VERIFYPEER, 0);
goto E_pgtxt7re0zF94c;
EaYK7vaIHoLSjTmy:
if (isset($_SERVER['HTTP_RANGE'])) {
goto FGJDlmYHtMQ53Fi_;
}
goto JkenMfjRgH0jzV4Z;
XnCwDlk3nCxSRR8Q:
header('Content-Range: bytes ' . $oa7ZLSHurUbiT1vG . '-' . ($oa7ZLSHurUbiT1vG + $rx8e6OgOxd7QgeeI) . '/' . $QoiP904uIE6OMneX);
goto TmBrJkX0XLjikaJe;
xvr0rQ4WIQW5BxeR:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_COOKIEFILE, dirname(__FILE__) . "/base/data/main/player/cookie/" . $v6wkZj0p1lz2eAe0 . ".txt");
goto s9lSdgpNF38UJDIs;
BF3erxwrhZUQAnF7:
$rx8e6OgOxd7QgeeI = $QoiP904uIE6OMneX;
goto EaYK7vaIHoLSjTmy;
sEE3GDOJ5yynf_1x:
$T7R90cp0_QsaazWL = curl_exec($t3aZfbKBL6T8nBPr);
goto J1MMzPIRCNqiiyoG;
qK9P_BwUWt08zIb0:
$t3aZfbKBL6T8nBPr = curl_init();
goto nY0X7ERfeWB_xjsQ;
ZTwgKlymeK5bujRz:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_NOBODY, true);
goto gHIDSdq1Et6xfRnj;
E_pgtxt7re0zF94c:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_USERAGENT, $nn2Qb8mKyn2EBJ09);
goto Z3bLsUeQsHJRZpSd;
h4rWlZHB4HvZ0YMW:
error_reporting(0);
goto Hj0cIAboxrUHLkHz;
wgb2OCm4YvUXlsCe:
header('HTTP/1.1 206 Partial Content');
goto CG22BHAMp7mMVTlA;
nD_aGAfF3ZWcZ_0V:
$pNBNfglmkeNuETzf = "true";
goto gHNzEwUEXQwfyMxt;
TLMcsnLbRvuA2TX8:
H78VdJnxe60pOKJW:
goto KX2JDRutSek4BbGs;
DZ82EkpwHQnFM1pW:
$nn2Qb8mKyn2EBJ09 = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36";
goto qK9P_BwUWt08zIb0;
EyXZA8CQt0C0HkmQ:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_FRESH_CONNECT, true);
goto L0tPi0lrr7J3WySY;
JkenMfjRgH0jzV4Z:
$pNBNfglmkeNuETzf = "false";
goto pSBQhBOnQCS2ZX9p;
KX2JDRutSek4BbGs:
if ($pNBNfglmkeNuETzf == "true") {
goto eOHoyW9ioxpFbY25;
}
goto xeErxEAFJZdU0USs;
KlTk9FJFFlTS8jEp:
ini_set('max_execution_time', 0);
goto h4rWlZHB4HvZ0YMW;
YxIVCmc14NnYUIUn:
$vQxTuQeljcFuzR8w = strtotime('+5 hours');
goto tSmHKmaMiHIqWUZs;
Dg1qGpMuVVfG9HWG:
flush();
goto csBT6dMlf1S52UfU;
JjMWu24mGRrK67k4:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_VERBOSE, 1);
goto iCJ6Q_1C4kfmGCjL;
goHINMnqEY5SHPHf:
$f2Yd3hk7ALZpT_r0 = $AdQBpOtc1k0WnD9Q['video'][$N7yaF5WxzrDvINzW]['file'];
goto DZ82EkpwHQnFM1pW;
eC_Qb4jeq2D5p9Eg:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_SSL_VERIFYPEER, 0);
goto I3J3RQgQobK68g5J;
QLhfpqtLBDKVbLkL:
g1Au_sYLG6XoIzpb:
goto JjMWu24mGRrK67k4;
JE0VunL0zKUu9cMy:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_URL, $f2Yd3hk7ALZpT_r0);
goto xvr0rQ4WIQW5BxeR;
P5Lgngjdqf_iihFz:
$QoiP904uIE6OMneX = $ImnBEOb5zcKwy4xL;
goto rNBEotEhaboHWeoR;
rLSyfX75kmOR21X5:
$AdQBpOtc1k0WnD9Q = json_decode(file_get_contents("base/data/main/player/data/{$_GET['download']}.json"), true);
goto goHINMnqEY5SHPHf;
tSmHKmaMiHIqWUZs:
$v6wkZj0p1lz2eAe0 = $_GET['download'];
goto BbJHBu8fyGBuSLoB;
gHI27tQDfRiWGAzz:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_FOLLOWLOCATION, true);
goto Fkj7MDYsbWXpGXZE;
fiBqUCnYNQO7DCE7:
$oa7ZLSHurUbiT1vG = intval($tNLwAxH4tohQNp34[1]);
goto jzaYAN3D6IFZX3DY;
gHIDSdq1Et6xfRnj:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_RETURNTRANSFER, true);
goto sEE3GDOJ5yynf_1x;
dVwF33ocHra_LPBQ:
$oa7ZLSHurUbiT1vG = intval($tNLwAxH4tohQNp34[1]);
goto hE_oxieqFaSfgMzQ;
XL6uSSwR3gnvwJ2R:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_HTTPHEADER, $bPlc781gF4RdIHyQ);
goto QLhfpqtLBDKVbLkL;
Hj0cIAboxrUHLkHz:
if (!(isset($_GET['download']) && isset($_GET['label']) && isset($_GET['idplay']))) {
goto opnkW3DWM1Xe643I;
}
goto wYd19zbnMUak5F7h;
RoFc53WWfzggjOu1:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_URL, $f2Yd3hk7ALZpT_r0);
goto yCHuxoPOetDFsqVK;
Fkj7MDYsbWXpGXZE:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_HEADER, true);
goto C9OMN960a8HmTbAS;
R7wBsx8ALzPXZnal:
curl_exec($t3aZfbKBL6T8nBPr);
goto Dg1qGpMuVVfG9HWG;
I3J3RQgQobK68g5J:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_USERAGENT, $nn2Qb8mKyn2EBJ09);
goto ZTwgKlymeK5bujRz;
gHNzEwUEXQwfyMxt:
preg_match('/bytes=(\\d+)-(\\d+)?/', $_SERVER['HTTP_RANGE'], $tNLwAxH4tohQNp34);
goto fiBqUCnYNQO7DCE7;
GYq_iCYFYqqpJbIb:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_TIMEOUT, 222222);
goto RoFc53WWfzggjOu1;
gc8XRRJLvi6_uK2N:
undTmvk63I5n113l:
goto WYBFMbNsedvrTAdz;
vuTSQDodvy7ZginP:
$bPlc781gF4RdIHyQ = array('Range: bytes=' . $oa7ZLSHurUbiT1vG . '-' . ($oa7ZLSHurUbiT1vG + $rx8e6OgOxd7QgeeI) . '');
goto XL6uSSwR3gnvwJ2R;
wYd19zbnMUak5F7h:
$HwMMDtxUvKjVpP_n = strtotime('now');
goto YxIVCmc14NnYUIUn;
jzaYAN3D6IFZX3DY:
$rx8e6OgOxd7QgeeI = $ImnBEOb5zcKwy4xL - $oa7ZLSHurUbiT1vG - 1;
goto TLMcsnLbRvuA2TX8;
J1MMzPIRCNqiiyoG:
$ImnBEOb5zcKwy4xL = curl_getinfo($t3aZfbKBL6T8nBPr, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
goto Ekog1aGi1L6MN0Pk;
M8CbGYAz19Of_Z2s:
curl_setopt($t3aZfbKBL6T8nBPr, CURLOPT_HEADER, false);
goto EyXZA8CQt0C0HkmQ;
afiayscHY207PzxD:
$t3aZfbKBL6T8nBPr = curl_init();
goto t39Q8bdFIsEVEcIY;
WYBFMbNsedvrTAdz:
opnkW3DWM1Xe643I:

?>